#ifndef NO_STREAM

#define Uses_TDeskTop
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass CLY_EXPORT RDeskTop( TDeskTop::name,
                           TDeskTop::build,
                           __DELTA(TDeskTop)
                         );

#endif

