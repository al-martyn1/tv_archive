/*
 *      Turbo Vision - Version 2.0
 *
 *      Copyright (c) 1994 by Borland International
 *      All Rights Reserved.
 *

Modified by Robert H�hne to be used for RHIDE.

 *
 *
 */

#if defined( Uses_TBackground )

#include <tv/backgrnd.h>

#endif


#if defined( Uses_TDeskTop )

#include <tv/desktop.h>

#endif


#if defined( Uses_TProgram )

#include <tv/program.h>

#endif

#if defined( Uses_TApplication )

#include <tv/applictn.h>

#endif


