#ifndef NO_STREAM

#define Uses_TMenuBar
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass CLY_EXPORT RMenuBar( TMenuBar::name,
                           TMenuBar::build,
                           __DELTA(TMenuBar)
                         );

#endif

