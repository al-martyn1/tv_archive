#ifndef NO_STREAM

#define Uses_TStreamableClass
#define Uses_TPXPictureValidator
#include <tv.h>

TStreamableClass CLY_EXPORT RPXPictureValidator( TPXPictureValidator::name,
                         TPXPictureValidator::build,
                         __DELTA(TPXPictureValidator)
                       );

#endif

