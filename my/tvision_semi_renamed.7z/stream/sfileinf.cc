#ifndef NO_STREAM

#define Uses_TFileInfoPane
#define Uses_TStreamableClass
#include <tv.h>

TStreamableClass CLY_EXPORT RFileInfoPane( TFileInfoPane::name,
                                TFileInfoPane::build,
                                __DELTA(TFileInfoPane)
                              );

#endif

