#ifndef NO_STREAM

#define Uses_TStreamableClass
#define Uses_TFilterValidator
#include <tv.h>

TStreamableClass CLY_EXPORT RFilterValidator( TFilterValidator::name,
                         TFilterValidator::build,
                         __DELTA(TFilterValidator)
                       );

#endif

