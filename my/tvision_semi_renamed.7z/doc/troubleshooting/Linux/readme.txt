Introduction:
-------------

The subdirectories contains four tests to determine various aspects of your
Linux console.
Please follow the instructions of each test.

SET
