//  NOVEMBER 27,1993      LIST VIEW BOX AND LIST VIEW DIALOG
//
//  The reason for these classes was that I needed the functionaltity of ListBox
//  but, I did not want to use a collection. I also wanted a 'cleaner' user interface.
//
//  FEATURES OF ListViewBox Class 
//  1-Muliple lists
//  2- Can use simple character list
//  3- Simple user interface, double click for empty line,hit return to 
//      edit existing data.
//  4- Easily modified for other types of data
//
//  I hope this is of some small value and would appreciate suggestions or
//  examples of what other users have done with it. I offer it freely
//  as a small payment for the help and code others have provided to me .
//
// CRAIG PORTER CIS- 70262,1047
//
